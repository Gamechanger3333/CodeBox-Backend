export const answer = 42;
export async function main() {
  return answer;
}
