const express = require("express");
function start() {
  const app = express();
  app.get("/", (req, res) => {
    res.send("ok");
  });
  return app;
}
module.exports = start;
